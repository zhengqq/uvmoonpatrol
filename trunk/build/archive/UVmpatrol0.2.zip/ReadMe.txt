--===---====---===---===---
 Ultraviolent Moon Patrol
--===---====---===---===---

--===---====---===---===---
        Disclaimer
--===---====---===---===---

This is purely a fan-made game seeking no profits and I take no credit for the original creation of this game. I do not have any legal means of justifying this game be anything but an educational release via open-source research, so if you rip off the code for a commercial project I can't really do anything to stop you. I do not hold any patents on Ultra, Violent, Moon, Patrol, or any combination of those words, so legally I have no rights on this release, its just for fun! :D

--===---====---===---===---
       How To Play
--===---====---===---===---

Control the Moon Buggy with the Arrow Keys.
Use the Left-Control to shoot the cannon and missiles.
Use the Space-Bar to jump.

Jumping on top of moon men will help you make it over canyons & boulders.

--===---====---===---===---
         History
--===---====---===---===---

Version 0.2 -
   Added guts to the blood fountain, converted all the arrays to STL vectors, optimized all the loops to use iterators, did some other fun stuff, added missile collision support for the jet men, etc.

Version 0.1 -
   Initial Release, not too much to see here. It crashes, yeah.

--===---====---===---===---
         Credits
--===---====---===---===---

Programming, Re-made Art, Resources: Cthulhu32 (Luke Arntson)

Original Moon Patrol created by Irem, American Release by Williams.

I take no credit for the original concept, art, music, idea, or anything to do with this game. This game entirely created as an appreciation to the original work of art that is Moon Patrol.

Contact Email: arntsonl@gmail.com